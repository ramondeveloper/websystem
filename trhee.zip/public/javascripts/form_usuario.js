$(document).ready(function () {
    $('#telefone').mask('(00)00000-0000');
})

function cancelar() {
    window.history.back()
}

function validar() {
    var nome = formuser.nome.value;
    var email = formuser.email.value;
    var usuario = formuser.usuario.value;
    var senha = formuser.senha.value;
    var senha1 = formuser.senha1.value;

    if (nome == "") {
        alerta('Preencha o campo nome!');
        formuser.nome.focus();
        return false;
    }

    else if (email == "" || email.indexOf('@') == -1) {
        alerta('Preencha o campo E-mail!');
        formuser.email.focus();
        return false;
    }

    else if (usuario == "" || usuario.length < 5) {
        alerta('Preencha o campo USUÁRIO, mínimo 5 caracteres!');
        formuser.usuario.focus();
        return false;
    }

    else if (senha == "" || senha.length <= 5) {
        alerta('Preencha o campo SENHA, mínimo 6 caracteres!');
        formuser.senha.focus();
        return false;
    }

    else if (senha != senha1) {
        alerta('As senhas divergem, preencha corretamente!');
        formuser.senha.focus();
        return false;
    }
    else{
        cad_usuario();
    }


}

function verificarCPF(c) {
    var i;
    s = c;
    var c = s.substr(0, 9);
    var dv = s.substr(9, 2);
    var d1 = 0;
    var v = false;

    for (i = 0; i < 9; i++) {
        d1 += c.charAt(i) * (10 - i);
    }
    if (d1 == 0) {
        alerta("CPF Inválido")
        v = true;
        return false;
    }
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(0) != d1) {
        v = true;
        return false;
    }

    d1 *= 2;
    for (i = 0; i < 9; i++) {
        d1 += c.charAt(i) * (11 - i);
    }
    d1 = 11 - (d1 % 11);
    if (d1 > 9) d1 = 0;
    if (dv.charAt(1) != d1) {
        alerta("CPF Inválido")
        v = true;
        return false;
    }
    if (!v) {
        
    }
}

function popLocalidade() {
    var httplocalidade = new XMLHttpRequest();
    httplocalidade.open('GET', '/banco/localidade', false);
    httplocalidade.send(null);

    var objlocalidade = JSON.parse(httplocalidade.responseText);

    var arrayLoc = [];
    var arrayId_Loc = [];

    var localidades = document.getElementById("localidadesUsuario");

    for (var i = 0; i < objlocalidade.length; i++) {

        arrayLoc[i] = objlocalidade[i].nm_Loc;
        arrayId_Loc[i] = objlocalidade[i].id_loc;

        var loc = document.createElement("option");
        var optloc = arrayLoc[i]
        var optlocid = arrayId_Loc[i]
        loc.textContent = optloc;
        loc.value = optlocid;

        localidades.appendChild(loc);
    }

}


function cad_usuario() {
    $.ajax({
        method: "POST",
        url: "/cadastro/usuariosCad",
        data: $("#formuser").serialize()
    })
        .done(function (resposta) {
            var msg;
            if (resposta == "erro") {
                msg = "Falha no cadastro, Por favor tente novamente!"
                alertaErro(msg)            
            }
            else if(resposta == "Sucesso") {
                msg = "Cadastro feito com sucesso!"
                alertaSucesso(msg)            
                document.getElementById("formuser").reset();
            }
            else if(resposta == "cpf-duplicado") {
                msg = "Este CPF já existe na base, caso tenha esquecido sua senha entre em contato com administrador"
                alerta(msg)
                           
            }
            else if(resposta == "usuario-duplicado") {
                msg = "Este usuario já existe na base, caso tenha esquecido sua senha entre em contato com administrador"
                alerta(msg)

            }
            else if(resposta == "email-duplicado") {
                msg = "Este e-mail já existe na base, caso tenha esquecido sua senha entre em contato com administrador"
                alerta(msg)           
            }
        });   
}

