$(document).ready(function () {
    popLocLab();
    var variaveis = location.search.split("=");
    var idSensor = parseInt(variaveis[1]);

    var httpSensor = new XMLHttpRequest();
    httpSensor.open("GET", '/banco/sensor/' + idSensor, false);
    httpSensor.send(null);

    var objSensor = JSON.parse(httpSensor.responseText);
    //console.log(objSensor);

    var nomeSensor = objSensor[0].nm_arduino;

    var httpLocLab = new XMLHttpRequest();
    httpLocLab.open("GET", '/banco/loc_lab/' + idSensor, false);
    httpLocLab.send(null);

    var loc_lab = JSON.parse(httpLocLab.responseText);
    console.log(loc_lab);

    $('#loc_sensor option[value="' + loc_lab[0].id_loc + '"]').attr('selected', 'selected');
    $('#lab_sensor option[value="' + loc_lab[0].id_locLab + '"]').attr('selected', 'selected');
    $('#idSensor').val(idSensor);
    $('#_idSensor').val(idSensor);
    $('#nomeSensor').val(nomeSensor);
    $('#loc_sensor').val()
    $('#atv').val(loc_lab[0].data_ativacao);

})

function popLocLab() {

    var dataAtv = new Date();
    var n = dataAtv.toLocaleDateString();
    document.getElementById("desatv").placeholder = n;

    var httplocalidade = new XMLHttpRequest();
    httplocalidade.open('GET', '/banco/localidade', false);
    httplocalidade.send(null);

    var objlocalidade = JSON.parse(httplocalidade.responseText);
    //console.log(objlocalidade);

    var arrayLoc = [];
    var arrayId_Loc = [];

    var localidades = document.getElementById("loc_sensor");

    for (var i = 0; i < objlocalidade.length; i++) {

        arrayLoc[i] = objlocalidade[i].nm_Loc;
        arrayId_Loc[i] = objlocalidade[i].id_loc;

        var loc = document.createElement("option");
        var optloc = arrayLoc[i]
        var optlocid = arrayId_Loc[i]
        loc.textContent = optloc;
        loc.value = optlocid;

        localidades.appendChild(loc);
    }

    var httpLab = new XMLHttpRequest();
    httpLab.open("GET", '/banco/laboratorioLista', false);
    httpLab.send(null);

    var objLab = JSON.parse(httpLab.responseText);
    //console.log(objLab);
    var arrayLab = [];
    var arrayLabId = [];

    var labs = document.getElementById("lab_sensor");
    labs.textContent = "";

    if (objLab.length == 0) {
        var labPadrao = document.createElement("option");
        labPadrao.textContent = "Não existem Labs disponíveis";
        labPadrao.value = null;
        labPadrao.disabled = true;
        labPadrao.selected = true;

        labs.appendChild(labPadrao);
    }

    for (var i = 0; i < objLab.length; i++) {
        arrayLab[i] = objLab[i].desc_Lab;
        arrayLabId[i] = objLab[i].id_locLab;

        if (i == 0) {
            var labPadrao = document.createElement("option");
            labPadrao.textContent = "Selecione um Laboratório"
            labPadrao.value = null;
            labPadrao.disabled = true;
            labPadrao.selected = true;

            labs.appendChild(labPadrao);
        }

        var lab = document.createElement("option");
        var optLab = arrayLab[i]
        var optLabId = arrayLabId[i]
        lab.textContent = optLab;
        lab.value = optLabId;

        labs.appendChild(lab);
    }



}