$(document).ready(function () {
    popLocalidade();
})

function popLocalidade() {
    var httplocalidade = new XMLHttpRequest();
    httplocalidade.open('GET', '/banco/localidade', false);
    httplocalidade.send(null);

    var objlocalidade = JSON.parse(httplocalidade.responseText);
    console.log(objlocalidade);

    var arrayLoc = [];
    var arrayId_Loc = [];

    var localidades = document.getElementById("Loc");

    for (var i = 0; i < objlocalidade.length; i++) {

        arrayLoc[i] = objlocalidade[i].nm_Loc;
        arrayId_Loc[i] = objlocalidade[i].id_loc;

        var loc = document.createElement("option");
        var optloc = arrayLoc[i]
        var optlocid = arrayId_Loc[i]
        loc.textContent = optloc;
        loc.value = optlocid;

        localidades.appendChild(loc);
    }

}

function validacao() {

    /*if(document.cadLab.cadLabs.value=="Selecionar Laboratório"){
        alert("Selecione Laboratório");
        return false;
    }*/

    if (document.cadLab.locLab.value == "Selecionar Localidade") {
        alerta("Selecionar Localidade");
    }
    else {
        cad_laboratorio();
    }

}

function cad_laboratorio() {
    $.ajax({
        method: "POST",
        url: "/cadastro/labCad",
        data: $("#cadLab").serialize()
    })
        .done(function (resposta) {
            console.log(resposta);
            var msg;
            if (resposta == "erro") {
                msg = "Falha no cadastro, Por favor tente novamente!";
                alertaErro(msg);
            }
            else if (resposta == "Sucesso") {
                msg = "Cadastro feito com sucesso!";
                alertaSucesso(msg);
                document.getElementById("cadLab").reset();

            }
        });
}
