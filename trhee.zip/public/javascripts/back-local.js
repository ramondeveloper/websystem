function populaTabela(){
    var httpLocalidade = new XMLHttpRequest();
    httpLocalidade.open("GET", "/banco/localidadeLista", false);
    httpLocalidade.send(null);
    
    var objLista = JSON.parse(httpLocalidade.responseText);

    var tabela = $('.estrutura_table').DataTable();

    for(var i = 0; i < objLista.length; i++){
        tabela.row.add([
            objLista[i].id_loc,
            objLista[i].cep,
            objLista[i].estado,
            objLista[i].cidade,
            objLista[i].endereco,
            objLista[i].nm_Loc,
            objLista[i].numero,
            objLista[i].bairro
        ]).draw()
    }
}