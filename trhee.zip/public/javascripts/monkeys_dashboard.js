//Executar ao iniciar o arquivo
$(document).ready(function () {
    //Função de troca dos LABS ao mudar LOCALIDADE
    $('#localidades').change(function () {

        selecionado = parseInt($('#localidades option:selected').val());

        modalLocalidade(selecionado);
        limparCampos();

        var httpLab = new XMLHttpRequest();
        httpLab.open("GET", '/dashboard/lab/' + selecionado, false);
        httpLab.send(null);

        var objLab = JSON.parse(httpLab.responseText);

        var arrayLab = [];
        var arrayLabId = [];

        var labs = document.getElementById("labs");
        labs.textContent = "";
        var refrigerador = document.getElementById("refrigerador");
        refrigerador.textContent = "";

        if (objLab.length == 0) {
            var semLab = document.createElement("option");
            semLab.textContent = "Não há laboratórios cadastrados"
            semLab.value = null;
            semLab.disabled = true;
            semLab.selected = true;

            labs.appendChild(semLab);

            var semRefri = document.createElement("option");
            semRefri.textContent = "Não há refrigeradores cadastrados"
            semRefri.value = null;
            semRefri.disabled = true;
            semRefri.selected = true;

            refrigerador.appendChild(semRefri);
            return;

            return;
        }

        for (var i = 0; i < objLab.length; i++) {
            arrayLab[i] = objLab[i].desc_lab;
            arrayLabId[i] = objLab[i].id_loclab;

            if (i == 0) {
                var labPadrao = document.createElement("option");
                labPadrao.textContent = "Selecione um Laboratório"
                labPadrao.value = null;
                labPadrao.disabled = true;
                labPadrao.selected = true;

                labs.appendChild(labPadrao);

                var refriPadrao = document.createElement("option");
                refriPadrao.textContent = "Selecione um Refrigerador"
                refriPadrao.value = null;
                refriPadrao.disabled = true;
                refriPadrao.selected = true;

                refrigerador.appendChild(refriPadrao);
            }

            var lab = document.createElement("option");
            var optLab = arrayLab[i]
            var optLabId = arrayLabId[i]
            lab.textContent = optLab;
            lab.value = optLabId;

            labs.appendChild(lab);
        }

    })

    //Função de alterar Chart quando mudar o Lab
    $('#labs').change(function () {

        limparCampos();

        var labSelecionado = parseInt($('#labs option:selected').val());
        var httpSensor = new XMLHttpRequest();
        httpSensor.open('GET', '/dashboard/arduinoNome/' + labSelecionado, false);
        httpSensor.send(null);
        var objSensor = JSON.parse(httpSensor.responseText);

        var arraySensor = [];
        var arrayId_Sensor = [];

        var refrigerador = document.getElementById("refrigerador");
        refrigerador.textContent = "";

        if (objSensor.length == 0) {
            var semRefri = document.createElement("option");
            semRefri.textContent = "Não há refrigeradores cadastrados"
            semRefri.value = null;
            semRefri.disabled = true;
            semRefri.selected = true;

            refrigerador.appendChild(semRefri);
            return;
        }

        for (var i = 0; i < objSensor.length; i++) {

            if (i == 0) {
                var refriPadrao = document.createElement("option");
                refriPadrao.textContent = "Selecione um Refrigerador"
                refriPadrao.value = null;
                refriPadrao.disabled = true;
                refriPadrao.selected = true;

                refrigerador.appendChild(refriPadrao);
            }

            arraySensor[i] = objSensor[i].nm_arduino;
            arrayId_Sensor[i] = objSensor[i].id_Arduino;

            var refri = document.createElement("option");
            var optRefrigerador = arraySensor[i]
            var optRefrigeradorid = arrayId_Sensor[i]
            refri.textContent = optRefrigerador;
            refri.value = optRefrigeradorid;

            refrigerador.appendChild(refri);
        }

    })
});

$('#refrigerador').change(function () {

    var refrigeradorSelecionado = parseInt($('#refrigerador option:selected').val());

    var httpSensor = new XMLHttpRequest();
    httpSensor.open('GET', '/dashboard/arduino/' + refrigeradorSelecionado, false);
    httpSensor.send(null);
    var objSensor = JSON.parse(httpSensor.responseText);

    document.getElementById('nomeArduino').innerHTML = objSensor[0].nm_arduino;

    modalConfig(objSensor[0]);
    atualizaChartComParametro(refrigeradorSelecionado);
    getsensorconfigs = false;

})

function atualizaChartComParametro(refrigerador) {

    if (isNaN(refrigerador)) {
        return;
    }

    $.ajax({
        method: "GET",
        url: "/dashboard/coleta/" + refrigerador,

    })
        .done(function (data) {
            dados = data;
            if (dados.length == 0) {
                limparCampos();
                return;
            }
            else {
                chartTemp.data.datasets[0].data = dados.temp;
                chartUmi.data.datasets[0].data = dados.umi;
                chartTemp.data.labels = dados.time;
                chartUmi.data.labels = dados.time;
                var arrayTemp = dados.temp;
                var arrayUmi = dados.umi;
            }
            chartTemp.update();
            chartUmi.update();


            // ANALYTICS TEMPERATURA
            var maxTemp = -999;
            var minTemp = 999;
            var somaTemp = 0;
            for (var i = 0; i < arrayTemp.length; i++) {
                somaTemp += parseInt(arrayTemp[i]);
                if (arrayTemp[i] > maxTemp) {
                    maxTemp = arrayTemp[i];
                }
                if (arrayTemp[i] < minTemp) {
                    minTemp = arrayTemp[i];
                }
            }
            var mediaTemp = somaTemp / parseInt(arrayTemp.length);
            document.getElementById('mediaTemp').innerHTML = parseFloat(mediaTemp.toFixed(1)) + "<b> °C</b>";
            if (minTemp != 999) {
                document.getElementById('minTemp').innerHTML = parseFloat(minTemp.toFixed(1)) + "<b> °C</b>";
            }
            if (maxTemp != -999) {
                document.getElementById('maxTemp').innerHTML = parseFloat(maxTemp.toFixed(1)) + "<b> °C</b>";
            }

            // ANALYTICS UMIDADE
            var maxUmi = -999;
            var minUmi = 999;
            var somaUmi = 0;
            for (var i = 0; i < arrayUmi.length; i++) {
                somaUmi += parseInt(arrayUmi[i]);
                if (arrayUmi[i] > maxUmi) {
                    maxUmi = arrayUmi[i];
                }
                if (arrayUmi[i] < minUmi) {
                    minUmi = arrayUmi[i];
                }
            }
            var mediaUmi = somaUmi / parseInt(arrayUmi.length);
            document.getElementById('mediaUmi').innerHTML = parseFloat(mediaUmi.toFixed(1)) + "<b> %</b>";
            if (minUmi != 999) {
                document.getElementById('minUmi').innerHTML = parseFloat(minUmi.toFixed(1)) + "<b> %</b>";
            }
            if (maxUmi != -999) {
                document.getElementById('maxUmi').innerHTML = parseFloat(maxUmi.toFixed(1)) + "<b> %</b>";
            }

            if (arrayTemp[arrayTemp.length - 1] != undefined) {
                document.getElementById('tempDashboard').innerHTML = arrayTemp[arrayTemp.length - 1] + '°C'
            }
            if (arrayUmi[arrayTemp.length - 1] != undefined) {
                document.getElementById('umiDashboard').innerHTML = arrayUmi[arrayUmi.length - 1] + '%'
            }

            alertaSensor(refrigerador, arrayTemp[arrayTemp.length - 1], arrayUmi[arrayUmi.length - 1]);
        });
}



//Criação Char TEMPERATURA
var ctxTemp = document.getElementById('chartTemp').getContext('2d');
var cfgChartTemp =
{
    type: 'line',
    data: {
        datasets: [{
            label: "Temperatura",
            borderColor: 'rgb(255, 0, 0)'
        }]
    },
    options: {
        animation: {
            duration: 0
        },
        scales: {
            yAxes: [{
                display: true,
                scaleLabel: {
                    display: true,
                    labelString: 'Graus Celsius'
                },
                ticks: {
                    beginAtZero: true,
                    steps: 5,
                    stepValue: 5,
                    max: 40
                }
            }]
        }
    }
};
var chartTemp = new Chart(ctxTemp, cfgChartTemp);

//Criação Chart UMIDADE
var ctxUmi = document.getElementById('chartUmi').getContext('2d');
var cfgChartUmi =
{
    type: 'line',
    data: {
        datasets: [{
            label: "Umidade",
            borderColor: 'rgb(0, 0, 255)'
        }]
    },
    options: {
        animation: {
            duration: 0
        },
        scales: {
            yAxes: [{
                display: true,
                scaleLabel: {
                    display: true,
                    labelString: 'Porcentagem'
                },
                ticks: {
                    beginAtZero: true,
                    steps: 10,
                    stepValue: 5,
                    max: 100
                }
            }]
        }
    }
};
var chartUmi = new Chart(ctxUmi, cfgChartUmi);

function popSelects() {

    var httpSession = new XMLHttpRequest();
    httpSession.open("GET", "/users/session", false);
    httpSession.send(null);
    var usuarioLogado = JSON.parse(httpSession.responseText);

    var httpLocalidade = new XMLHttpRequest();

    if (usuarioLogado[0].idAcesso == 2) {
        httpLocalidade.open('GET', '/dashboard/localidadePorUsuario/' + usuarioLogado[0].idLocalidade, false)
        httpLocalidade.send(null);
    } else {
        httpLocalidade.open('GET', '/dashboard/localidade', false);
        httpLocalidade.send(null);
    }

    var objlocalidade = JSON.parse(httpLocalidade.responseText);

    var arrayLoc = [];
    var arrayId_Loc = [];

    var localidades = document.getElementById("localidades");

    for (var i = 0; i < objlocalidade.length; i++) {

        arrayLoc[i] = objlocalidade[i].nm_Loc;
        arrayId_Loc[i] = objlocalidade[i].id_loc;

        var loc = document.createElement("option");
        var optloc = arrayLoc[i]
        var optlocid = arrayId_Loc[i]
        loc.textContent = optloc;
        loc.value = optlocid;

        localidades.appendChild(loc);
    }

}

function limparCampos() {

    document.getElementById('tempDashboard').innerHTML = "";
    document.getElementById('umiDashboard').innerHTML = "";

    document.getElementById('mediaUmi').innerHTML = "";
    document.getElementById('maxUmi').innerHTML = "";
    document.getElementById('minUmi').innerHTML = "";

    document.getElementById('mediaTemp').innerHTML = "";
    document.getElementById('maxTemp').innerHTML = "";
    document.getElementById('minTemp').innerHTML = "";

    document.getElementById('nomeArduino').innerHTML = "";

    document.getElementById("mensagemArduino").innerHTML = `<b>Selecione um Refrigerador.</b>`;

    document.getElementById('logradouroLoc').innerHTML = "";
    document.getElementById('cidadeLoc').innerHTML = "";
    document.getElementById('bairroLoc').innerHTML = "";

    var arrayVazio = [];
    chartTemp.data.datasets[0].data = arrayVazio;
    chartUmi.data.datasets[0].data = arrayVazio;
    chartTemp.update();
    chartUmi.update();

    contadorTempMax = 0;
    contadorTempMin = 0;
    contadorUmiMax = 0;
    contadorUmiMin = 0;
   
    
}

function enviarEmail(mensagem) {

    var locSelecionado = parseInt($('#localidades option:selected').val());
    var local = $('#localidades option:selected').text();

    var httpAdm = new XMLHttpRequest();
    httpAdm.open('GET', '/banco/admLoc/' + locSelecionado, false);
    httpAdm.send(null);

    var objAdm = JSON.parse(httpAdm.responseText);

    //API EMAIL
    const token = '2d05d5ec-4e5b-4c21-aed3-6257c141e445';
    const isp = 'smtp25.elasticemail.com';
    const username = 'allantnunes@gmail.com';

    for (i = 0; i < objAdm.length; i++) {
        var comecoMsg = `Olá, <b>${objAdm[i].nm_usuario}</b>.<br> Este é um e-mail automático. Sensores da Unidade: ${local} dispararam!<br><br>`
        comecoMsg = comecoMsg + mensagem;

        const remetente = 'monkeyshealthcare@gmail.com';
        var destinatario = objAdm[i].email;
        var assunto = 'ALERTA! Sensores da Unidade: ' + local + ' dispararam!';

        Email.send(
            remetente,
            destinatario,
            assunto,
            mensagem,
            isp,
            username,
            token);
        console.log("Email enviado para " + objAdm[i].email);
    }

}

function modalLocalidade(idLoc) {
    if (isNaN(idLoc)) {
        return;
    }

    var httpCard = new XMLHttpRequest();
    httpCard.open("GET", '/banco/locEndereco/' + selecionado, false);
    httpCard.send(null);

    var objCard = JSON.parse(httpCard.responseText);

    document.getElementById('logradouroLoc').innerHTML = objCard[0].endereco + ", " + objCard[0].numero
    document.getElementById('cidadeLoc').innerHTML = objCard[0].cidade;
    document.getElementById('bairroLoc').innerHTML = objCard[0].bairro;
}

function modalConfig(arduino) {

    if (arduino != {}) {
        document.getElementById("mensagemArduino").innerHTML = `<b>Sensor: </b>${arduino.nm_arduino}
        <b>Temperatura Máxima:</b> ${arduino.temp_max} °C<br>
        <b>Temperatura Mínima:</b> ${arduino.temp_min} °C<br>
        <b>Umidade Máxima:</b> ${arduino.umi_max} %<br>
        <b>Umidade Mínima:</b> ${arduino.umi_min} %<br>`
    }
}

var contadorTempMax = 0;
var contadorTempMin = 0;
var contadorUmiMax = 0;
var contadorUmiMin = 0;

var verificador = true;
var getsensorconfigs = false;
var sensor;

function alertaSensor(idLab, tempAtual, umiAtual) {
    var mensagem = "";
    if (isNaN(idLab)) {
        return;
    }
    
    if (getsensorconfigs == true){
        alertastempumi();
    }
    if (getsensorconfigs == "não tem configs"){
        return;
    }


    else if (getsensorconfigs == false) {
        var httpSensor = new XMLHttpRequest();
        httpSensor.open('GET', '/banco/sensorPorLab/' + idLab, false);
        httpSensor.send(null);
        var objSensor = JSON.parse(httpSensor.responseText);
        sensor = objSensor[0];
        console.log(sensor)
        if(sensor == undefined){
            alerta("Este sensor ainda não foi configurado com parametros de temperatura e umidade Min/Max")
            getsensorconfigs = "não tem configs";
            document.getElementById("mensagemArduino").innerHTML = `<b>Este sensor ainda não foi configurado com parametros de temperatura e umidade Min/Max.</b>`;
        }
        else{
            getsensorconfigs = true;
            alertastempumi();
        }
    }
    
    // Verificação de Temperatura Máxima 
    function alertastempumi(){
        console.log("aqui")
    if (tempAtual > sensor.temp_max) {

        contadorTempMax += 1;
        // console.log("Contador Temp max: " + contadorTempMax);
        if (contadorTempMax > 3) {

            verificador = true;

            if (contadorTempMax == 4) {

                mensagem = `<b>ALERTA! Temperatura limite atingida!</b> <br><br>
                <b>Unidade:</b> ${$('#localidades option:selected').text()}<br>
                <b>Laboratório:</b> ${$('#labs option:selected').text()}<br>
                <b>Refrigerador:</b> ${sensor.nm_arduino} <br>
                <b>Temperatura máxima permitida</b> ${sensor.temp_max} °C<br>
                <b>Temperatura atual:</b> ${tempAtual} °C`;

                document.getElementById('mensagemAlerta').innerHTML = mensagem;
                mensagemTelegram = `*ALERTA! Temperatura limite atingida!* \n\n*Unidade:* ${$('#localidades option:selected').text()}\n*Laboratório:* ${$('#labs option:selected').text()}\n*Refrigerador:* ${sensor.nm_arduino}\n*Temperatura máxima permitida:* ${sensor.temp_max} °C\n*Temperatura atual:* ${tempAtual} °C`;

                $.ajax({
                    type: 'POST',
                    url: '/telegram_bot/alerta',
                    data: { 'msg': mensagemTelegram }
                });

                enviarEmail(mensagem);

                $('#modalAlerta').modal('toggle');

                mudarCores();
            }

        }
    }

    // Verificação de Temperatura Mínima 
    if (tempAtual < sensor.temp_min) {

        contadorTempMin += 1;
        // console.log("Contador Temp min: " + contadorTempMin);
        if (contadorTempMin > 3) {

            verificador = true;

            if (contadorTempMin == 4) {

                mensagem = `<b>ALERTA! Temperatura limite atingida!</b> <br><br>
                <b>Unidade:</b> ${$('#localidades option:selected').text()}<br>
                <b>Laboratório:</b> ${$('#labs option:selected').text()}<br>
                <b>Refrigerador:</b> ${sensor.nm_arduino} <br>
                <b>Temperatura mínima permitida:</b> ${sensor.temp_min} °C<br>
                <b>Temperatura atual:</b> ${tempAtual} °C`;

                document.getElementById('mensagemAlerta').innerHTML = mensagem;
                mensagemTelegram = `*ALERTA! Temperatura limite atingida!* \n\n*Unidade:* ${$('#localidades option:selected').text()}\n*Laboratório:* ${$('#labs option:selected').text()}\n*Refrigerador:* ${sensor.nm_arduino}\n*Temperatura máxima permitida:* ${sensor.temp_min} °C\n*Temperatura atual:* ${tempAtual} °C`;

                $.ajax({
                    type: 'POST',
                    url: '/telegram_bot/alerta',
                    data: { 'msg': mensagemTelegram }
                });

                enviarEmail(mensagem);

                $('#modalAlerta').modal('toggle');

                mudarCores();
            }

        }
    }

    // Verificação de Umidade Máxima 
    if (umiAtual > sensor.umi_max) {

        contadorUmiMax += 1;
        // console.log("Contador Umi max: " + contadorUmiMin);
        if (contadorUmiMax > 3) {

            verificador = true;

            if (contadorUmiMax == 4) {

                mensagem = `<b>ALERTA! Umidade limite atingida!</b> <br><br>
                <b>Unidade:</b> ${$('#localidades option:selected').text()}<br>
                <b>Laboratório:</b> ${$('#labs option:selected').text()}<br>
                <b>Refrigerador:</b> ${sensor.nm_arduino} <br>
                <b>Umidade máxima permitida:</b> ${sensor.umi_max} %<br>
                <b>Umidade atual:</b> ${umiAtual} %`;

                document.getElementById('mensagemAlerta').innerHTML = mensagem;
                mensagemTelegram = `*ALERTA! Umidade limite atingida!* \n\n*Unidade:* ${$('#localidades option:selected').text()}\n*Laboratório:* ${$('#labs option:selected').text()}\n*Refrigerador:* ${sensor.nm_arduino}\n*Umidade máxima permitida:* ${sensor.umi_max} %\n*Umidade atual:* ${umiAtual} %`;

                $.ajax({
                    type: 'POST',
                    url: '/telegram_bot/alerta',
                    data: { 'msg': mensagemTelegram }
                });

                enviarEmail(mensagem);

                $('#modalAlerta').modal('toggle');

                mudarCores();
            }

        }
    }

    // Verificação de Umidade Mínima
    if (umiAtual < sensor.umi_min) {

        contadorUmiMin += 1;
        // console.log("Contador Umi min: " + contadorUmiMin);
        if (contadorUmiMin > 3) {

            verificador = true;

            if (contadorUmiMin == 4) {

                mensagem = `<b>ALERTA! Umidade limite atingida!</b> <br><br>
                <b>Unidade:</b> ${$('#localidades option:selected').text()}<br>
                <b>Laboratório:</b> ${$('#labs option:selected').text()}<br>
                <b>Refrigerador:</b> ${sensor.nm_arduino} <br>
                <b>Umidade mínima permitida:</b> ${sensor.umi_min} %<br>
                <b>Umidade atual:</b> ${umiAtual} %`;

                document.getElementById('mensagemAlerta').innerHTML = mensagem;
                mensagemTelegram = `*ALERTA! Umidade limite atingida!* \n\n*Unidade:* ${$('#localidades option:selected').text()}\n*Laboratório:* ${$('#labs option:selected').text()}\n*Refrigerador:* ${sensor.nm_arduino}\n*Umidade mínima permitida:* ${sensor.umi_min} %\n*Umidade atual:* ${umiAtual} %`;

                $.ajax({
                    type: 'POST',
                    url: '/telegram_bot/alerta',
                    data: { 'msg': mensagemTelegram }
                });

                enviarEmail(mensagem);

                $('#modalAlerta').modal('toggle');

                mudarCores();
            }

        }
    }

    function mudarCores() {

        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        var corAtual = 0;

        async function loop() {
            if (verificador == true) {
                if (corAtual == 0) {
                    $('#modalAlerta').css({ "background-color": "rgb(255,0,0,0.5)" });
                    corAtual = 1;
                } else {
                    $('#modalAlerta').css({ "background-color": "rgb(255,255,0,0.5" });
                    corAtual = 0;
                }
                await sleep(500);
                loop();
            }
        }

        loop();

    }
}
}

function estouCiente() {
    verificador = false;
    $('#modalAlerta').modal('hide');

    contadorTempMax = -120;
    contadorTempMin = -120;
    contadorUmiMax = -120;
    contadorUmiMin = -120;

}

setInterval(() => {
    atualizaChartComParametro(parseInt($('#refrigerador option:selected').val()));
}, 1000);
