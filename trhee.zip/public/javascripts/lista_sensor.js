function populaTabela() {
    var httpSensor = new XMLHttpRequest();
    httpSensor.open("GET", "/banco/sensorLista", false);
    httpSensor.send(null);

    var objLista = JSON.parse(httpSensor.responseText);

    var tabela = $('.estrutura_table').DataTable();
    

    for (var i = 0; i < objLista.length; i++) {

        var statusAux = "Inativo";
        if(objLista[i].status == true){
            statusAux = "Ativo";
        }

        tabela.row.add([
            objLista[i].id_arduino,
            objLista[i].nm_arduino,
            objLista[i].nm_loc,
            objLista[i].desc_lab,
            objLista[i].data_ativacao[0],
            objLista[i].data_desativacao,
            statusAux,
            '<a href="/html/edicao_sensor.html?id='+objLista[i].id_arduino+'"><span class="glyphicon glyphicon-pencil"></span> Editar</a>',
        ]).draw();
   
    }
}