//Executar ao iniciar o arquivo
$(document).ready(function () {
    
    $('#loc_sensor').change(function () {

        selecionado = parseInt($('#loc_sensor option:selected').val());
        console.log(selecionado)

        var httpLab = new XMLHttpRequest();
        httpLab.open("GET", '/banco/lab/' + selecionado, false);
        httpLab.send(null);

        var objLab = JSON.parse(httpLab.responseText);
        console.log(objLab);
        var arrayLab = [];
        var arrayLabId = [];

        var labs = document.getElementById("lab_sensor");
        labs.textContent = "";

        if (objLab.length == 0) {
            var labPadrao = document.createElement("option");
            labPadrao.textContent = "Não existem Labs disponíveis";
            labPadrao.value = null;
            labPadrao.disabled = true;
            labPadrao.selected = true;

            labs.appendChild(labPadrao);
        }

        for (var i = 0; i < objLab.length; i++) {
            arrayLab[i] = objLab[i].desc_lab;
            arrayLabId[i] = objLab[i].id_loclab;

            if (i == 0) {
                var labPadrao = document.createElement("option");
                labPadrao.textContent = "Selecione um Laboratório"
                labPadrao.value = null;
                labPadrao.disabled = true;
                labPadrao.selected = true;

                labs.appendChild(labPadrao);
            }

            var lab = document.createElement("option");
            var optLab = arrayLab[i]
            var optLabId = arrayLabId[i]
            lab.textContent = optLab;
            lab.value = optLabId;

            labs.appendChild(lab);
        }

    })
})

function validacao() {
    if (document.cadSensor.locSensor.value == "Selecione a Unidade") {
        alerta('Por favor, selecione o Local');
        document.cadSensor.locSensor.focus();
        return false;
    }
    else if (document.cadSensor.labSensor.value == "Selecione o Laboratório") {
        alerta('Por favor, selecione o Laboratório');
        document.cadSensor.labSensor.focus();
        return false;
    }
    else if (document.cadSensor.statusSensor.value == "") {
        alerta('Por favor, selecione o Status');
        document.cadSensor.statusSensor.focus();
        return false;
    }
    else{
        cad_sensor();
    }
    
}

function popLocalidade() {

    var dataAtv = new Date();
    var n = dataAtv.toLocaleDateString();
    document.getElementById("atv").placeholder = n;
    console.log(n)

    var httplocalidade = new XMLHttpRequest();
    httplocalidade.open('GET', '/banco/localidade', false);
    httplocalidade.send(null);

    var objlocalidade = JSON.parse(httplocalidade.responseText);
    console.log(objlocalidade);

    var arrayLoc = [];
    var arrayId_Loc = [];

    var localidades = document.getElementById("loc_sensor");

    for (var i = 0; i < objlocalidade.length; i++) {

        arrayLoc[i] = objlocalidade[i].nm_Loc;
        arrayId_Loc[i] = objlocalidade[i].id_loc;

        var loc = document.createElement("option");
        var optloc = arrayLoc[i]
        var optlocid = arrayId_Loc[i]
        loc.textContent = optloc;
        loc.value = optlocid;

        localidades.appendChild(loc);
    }

}

function cad_sensor() {
    $.ajax({
        method: "POST",
        url: "/cadastro/sensorCad",
        data: $("#formSensor").serialize()
    })
        .done(function (resposta) {
            var msg;
            if (resposta == "erro") {
                msg = "Falha no cadastro, Por favor tente novamente!"
                alertaErro(msg)            
            }
            else if(resposta == "Sucesso") {
                msg = "Cadastro feito com sucesso!"
                alertaSucesso(msg)
                document.getElementById("formSensor").reset();
            }
        });   
}