//Executar ao iniciar o arquivo
$(document).ready(function () {
    popLocalidade();
    $('#loc_sensor').change(function () {

        selecionado = parseInt($('#loc_sensor option:selected').val());

        var httpLab = new XMLHttpRequest();
        httpLab.open("GET", '/banco/lab/' + selecionado, false);
        httpLab.send(null);

        var objLab = JSON.parse(httpLab.responseText);
        var arrayLab = [];
        var arrayLabId = [];

        var labs = document.getElementById("lab_sensor");
        labs.textContent = "";

        zerarCampos();

        if (objLab.length == 0) {
            var labPadrao = document.createElement("option");
            labPadrao.textContent = "Não existem Labs disponíveis";
            labPadrao.value = null;
            labPadrao.disabled = true;
            labPadrao.selected = true;

            labs.appendChild(labPadrao);
        }

        for (var i = 0; i < objLab.length; i++) {
            arrayLab[i] = objLab[i].desc_lab;
            arrayLabId[i] = objLab[i].id_loclab;

            if (i == 0) {
                var labPadrao = document.createElement("option");
                labPadrao.textContent = "Selecione um Laboratório"
                labPadrao.value = null;
                labPadrao.disabled = true;
                labPadrao.selected = true;

                labs.appendChild(labPadrao);
            }

            var lab = document.createElement("option");
            var optLab = arrayLab[i]
            var optLabId = arrayLabId[i]
            lab.textContent = optLab;
            lab.value = optLabId;

            labs.appendChild(lab);
        }

    })

    $('#lab_sensor').change(function () {

        labSelecionado = parseInt($('#lab_sensor option:selected').val());

        var httpSensores = new XMLHttpRequest();
        httpSensores.open("GET", '/banco/sensorPorLab/' + labSelecionado, false);
        httpSensores.send(null);

        var objSensor = JSON.parse(httpSensores.responseText);
        var arraySensor = [];
        var arraySensorId = [];

        var sensores = document.getElementById("sensores");
        sensores.textContent = "";

        if (objSensor.length == 0) {
            var sensorPadrao = document.createElement("option");
            sensorPadrao.textContent = "Não existem Sensores nesse laboratório";
            sensorPadrao.value = null;
            sensorPadrao.disabled = true;
            sensorPadrao.selected = true;

            sensores.appendChild(sensorPadrao);
        }

        for (var i = 0; i < objSensor.length; i++) {
            arraySensor[i] = objSensor[i].nm_arduino;
            arraySensorId[i] = objSensor[i].id_Arduino;

            if (i == 0) {
                var sensorPadrao = document.createElement("option");
                sensorPadrao.textContent = "Selecione um Sensor"
                sensorPadrao.value = null;
                sensorPadrao.disabled = true;
                sensorPadrao.selected = true;

                sensores.appendChild(sensorPadrao);
            }

            var sensor = document.createElement("option");
            var optSensor = arraySensor[i]
            var optSensorId = arraySensorId[i]
            sensor.textContent = optSensor;
            sensor.value = optSensorId;

            sensores.appendChild(sensor);
        }

    })

    $('#sensores').change(function () {

        sensorSelecionado = parseInt($('#sensores option:selected').val());

        var httpSensor = new XMLHttpRequest();
        httpSensor.open("GET", '/banco/sensor/' + sensorSelecionado, false);
        httpSensor.send(null);

        var objSensor = JSON.parse(httpSensor.responseText);

        if (objSensor[0].status == true) {
            $('#status_ard').val("Ativo");
        } else {
            $('#status_ard').val("Inativo");
        }

        $('#temp_max').val(objSensor[0].temp_max);
        $('#temp_max').prop('disabled', false);

        $('#temp_min').val(objSensor[0].temp_min);
        $('#temp_min').prop('disabled', false);

        $('#umi_max').val(objSensor[0].umi_max);
        $('#umi_max').prop('disabled', false);

        $('#umi_min').val(objSensor[0].umi_min);
        $('#umi_min').prop('disabled', false);

    })
})

function validacao() {

    var temp_max = parseInt($('#temp_max').val());
    var temp_min = parseInt($('#temp_min').val());
    var umi_max = parseInt($('#umi_max').val());
    var umi_min = parseInt($('#umi_min').val());

    if (temp_max <= temp_min) {
        alert('A TEMPERATURA MÁXIMA não pode ser igual ou menor que a TEMPERATURA MÍNIMA.\nA diferença entre TEMPERATURA MÁXIMA e MÍNIMA precisa ser de no mínimo 1°C.')
        return false;
    } else if (umi_max <= umi_min) {
        alert('A UMIDADE MÁXIMA não pode ser igual ou menor que a UMIDADE MÍNIMA.')
        return false;
    } else {
        configurarSensor();
    }

}

function configurarSensor() {
    $.ajax({
        method: "POST",
        url: "/banco/configSensor",
        data: $("#configSensor").serialize()
    })
        .done(function (resposta) {
            var msg;
            if (resposta == "Erro") {
                msg = "Falha na Edição, Por favor tente novamente!"
                alertaErro(msg)
            }
            else if (resposta == "Sucesso") {
                msg = "Edição concluída com sucesso!"
                alertaSucesso(msg)
                document.getElementById("configSensor").reset();
            }

        });
}

function popLocalidade() {

    var httplocalidade = new XMLHttpRequest();
    httplocalidade.open('GET', '/banco/localidade', false);
    httplocalidade.send(null);

    var objlocalidade = JSON.parse(httplocalidade.responseText);

    var arrayLoc = [];
    var arrayId_Loc = [];

    var localidades = document.getElementById("loc_sensor");

    for (var i = 0; i < objlocalidade.length; i++) {

        arrayLoc[i] = objlocalidade[i].nm_Loc;
        arrayId_Loc[i] = objlocalidade[i].id_loc;

        var loc = document.createElement("option");
        var optloc = arrayLoc[i]
        var optlocid = arrayId_Loc[i]
        loc.textContent = optloc;
        loc.value = optlocid;

        localidades.appendChild(loc);
    }

}

function zerarCampos() {
    $('#temp_max').val('');
    $('#temp_max').prop('disabled', true);
    $('#temp_max').attr("placeholder", "°C");

    $('#temp_min').val('');
    $('#temp_min').prop('disabled', true);
    $('#temp_min').attr("placeholder", "°C");

    $('#umi_max').val('');
    $('#umi_max').prop('disabled', true);
    $('#umi_max').attr("placeholder", "%");

    $('#umi_min').val('');
    $('#umi_min').prop('disabled', true);
    $('#umi_min').attr("placeholder", "%");

    var sensores = document.getElementById("sensores");
    sensores.textContent = "";
    var sens = document.createElement("option");
    sens.textContent = "Primeiro selecione o Laboratório"
    sens.value = null;
    sens.disabled = true;
    sens.selected = true;
    sensores.appendChild(sens);
}