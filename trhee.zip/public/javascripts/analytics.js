//Executar ao iniciar o arquivo
$(document).ready(function () {
    //Função de troca dos LABS ao mudar LOCALIDADE
    $('#localidades').change(function () {

        selecionado = parseInt($('#localidades option:selected').val());

        limparCampos();

        var httpLab = new XMLHttpRequest();
        httpLab.open("GET", '/dashboard/lab/' + selecionado, false);
        httpLab.send(null);

        var objLab = JSON.parse(httpLab.responseText);

        var arrayLab = [];
        var arrayLabId = [];

        var labs = document.getElementById("labs");
        labs.textContent = "";
        var refrigerador = document.getElementById("refrigerador");
        refrigerador.textContent = "";

        if (objLab.length == 0) {
            var semLab = document.createElement("option");
            semLab.textContent = "Não há laboratórios cadastrados"
            semLab.value = null;
            semLab.disabled = true;
            semLab.selected = true;

            labs.appendChild(semLab);

            var semRefri = document.createElement("option");
            semRefri.textContent = "Não há refrigeradores cadastrados"
            semRefri.value = null;
            semRefri.disabled = true;
            semRefri.selected = true;

            refrigerador.appendChild(semRefri);
            return;

            return;
        }

        for (var i = 0; i < objLab.length; i++) {
            arrayLab[i] = objLab[i].desc_lab;
            arrayLabId[i] = objLab[i].id_loclab;

            if (i == 0) {
                var labPadrao = document.createElement("option");
                labPadrao.textContent = "Selecione um Laboratório"
                labPadrao.value = null;
                labPadrao.disabled = true;
                labPadrao.selected = true;

                labs.appendChild(labPadrao);

                var refriPadrao = document.createElement("option");
                refriPadrao.textContent = "Selecione um Refrigerador"
                refriPadrao.value = null;
                refriPadrao.disabled = true;
                refriPadrao.selected = true;

                refrigerador.appendChild(refriPadrao);
            }

            var lab = document.createElement("option");
            var optLab = arrayLab[i]
            var optLabId = arrayLabId[i]
            lab.textContent = optLab;
            lab.value = optLabId;

            labs.appendChild(lab);
        }

    })

    //Função de alterar Chart quando mudar o Lab
    $('#labs').change(function () {

        limparCampos();

        var labSelecionado = parseInt($('#labs option:selected').val());
        var httpSensor = new XMLHttpRequest();
        httpSensor.open('GET', '/dashboard/arduinoNome/' + labSelecionado, false);
        httpSensor.send(null);
        var objSensor = JSON.parse(httpSensor.responseText);

        var arraySensor = [];
        var arrayId_Sensor = [];

        var refrigerador = document.getElementById("refrigerador");
        refrigerador.textContent = "";

        if (objSensor.length == 0) {
            var semRefri = document.createElement("option");
            semRefri.textContent = "Não há refrigeradores cadastrados"
            semRefri.value = null;
            semRefri.disabled = true;
            semRefri.selected = true;

            refrigerador.appendChild(semRefri);
            return;
        }

        for (var i = 0; i < objSensor.length; i++) {

            if (i == 0) {
                var refriPadrao = document.createElement("option");
                refriPadrao.textContent = "Selecione um Refrigerador"
                refriPadrao.value = null;
                refriPadrao.disabled = true;
                refriPadrao.selected = true;

                refrigerador.appendChild(refriPadrao);
            }

            arraySensor[i] = objSensor[i].nm_arduino;
            arrayId_Sensor[i] = objSensor[i].id_Arduino;

            var refri = document.createElement("option");
            var optRefrigerador = arraySensor[i]
            var optRefrigeradorid = arrayId_Sensor[i]
            refri.textContent = optRefrigerador;
            refri.value = optRefrigeradorid;

            refrigerador.appendChild(refri);
        }

    })


    $('#refrigerador').change(function () {
        limparCampos();
        $("#periodo").attr("disabled", false);
        $("#periodoHis").attr("disabled", false);

    })

    $('#periodo').change(function () {
        limparCampos();
        var refrigeradorSelecionado = parseInt($('#refrigerador option:selected').val())

        atualizaChartComParametro(refrigeradorSelecionado);

    })

});


function modalRelatorio(){
    document.getElementById("modal_nmLoc").innerHTML = $("#localidades option:selected").text()
    document.getElementById("modal_nmLab").innerHTML = $("#labs option:selected").text()
    document.getElementById("modal_ref").innerHTML = $("#refrigerador option:selected").text()

}
function gerarRelatorio(){
//  $.ajax({
//         method: "GET",
//         url: "/analytics/coletahistorico" //+ $("#refrigerador option:selected").val(),
//         // data: $("#formHis").serialize()
//     })
//         .done(function (data) {
//             console.log($("#refrigerador option:selected").val())
                
//         });

var refrigeradorSelecionado = parseInt($('#refrigerador option:selected').val())
var periodoHisSelecionado = $('#periodoHis option:selected').val()
window.open(`/analytics/coletahistorico/${refrigeradorSelecionado}:${periodoHisSelecionado}`)
}

var dados;

function atualizaChartComParametro(refrigerador) {

    if (isNaN(refrigerador) || isNaN($('#periodo option:selected').val())) {
        return;
    }

    $.ajax({
        method: "POST",
        url: "/analytics/coletaAnalytics/" + refrigerador,
        data: $("#formAnalytics").serialize()
    })
        .done(function (data) {
            dados = data;
            if (dados == 'sem medições') {
                alerta("Não temos medições do periodo selecionado, verifique se o sensor esta ligado")
                limparCampos();
                return;
            }
            else if (dados.length != 0) {
                chartTemp.data.datasets[0].data = dados.temp;
                document.getElementById("medianaTemp").innerHTML = dados.medianaTemp.toFixed(2)
                document.getElementById("1QTemp").innerHTML = dados.quartil25Temp
                document.getElementById("3QTemp").innerHTML = dados.quartil75Temp
                document.getElementById("mediaTemp").innerHTML = dados.mediaTemp.toFixed(2)

                chartUmi.data.datasets[0].data = dados.umi;
                document.getElementById("medianaUmi").innerHTML = dados.medianaUmi.toFixed(2)
                document.getElementById("1QUmi").innerHTML = dados.quartil25Umi
                document.getElementById("3QUmi").innerHTML = dados.quartil75Umi
                document.getElementById("mediaUmi").innerHTML = dados.mediaUmi.toFixed(2)

                chartTemp.data.labels = dados.time;
                chartUmi.data.labels = dados.time;
            }
            chartTemp.update();
            chartUmi.update();
        });
}

//Criação Char TEMPERATURA
var ctxTemp = document.getElementById('chartTemp').getContext('2d');
var cfgChartTemp =
{
    type: 'line',
    data: {
        datasets: [{
            label: "Temperatura",
            borderColor: 'rgb(255, 0, 0)'
        }]
    },
    options: {
        animation: {
            duration: 0
        },
        scales: {
            yAxes: [{
                display: true,
                scaleLabel: {
                    display: true,
                    labelString: 'Graus Celsius'
                },
                ticks: {
                    beginAtZero: true,
                    steps: 5,
                    stepValue: 5,
                    max: 40
                }
            }]
        }
    }
};
var chartTemp = new Chart(ctxTemp, cfgChartTemp);

//Criação Chart UMIDADE
var ctxUmi = document.getElementById('chartUmi').getContext('2d');
var cfgChartUmi =
{
    type: 'line',
    data: {
        datasets: [{
            label: "Umidade",
            borderColor: 'rgb(0, 0, 255)'
        }]
    },
    options: {
        animation: {
            duration: 0
        },
        scales: {
            yAxes: [{
                display: true,
                scaleLabel: {
                    display: true,
                    labelString: 'Porcentagem'
                },
                ticks: {
                    beginAtZero: true,
                    steps: 10,
                    stepValue: 5,
                    max: 100
                }
            }]
        },
    }
};
var chartUmi = new Chart(ctxUmi, cfgChartUmi);

function popSelects() {

    var httpLocalidade = new XMLHttpRequest();


    httpLocalidade.open('GET', '/banco/localidade', false);
    httpLocalidade.send(null);
  

    var objlocalidade = JSON.parse(httpLocalidade.responseText);

    var arrayLoc = [];
    var arrayId_Loc = [];

    var localidades = document.getElementById("localidades");

    for (var i = 0; i < objlocalidade.length; i++) {

        arrayLoc[i] = objlocalidade[i].nm_Loc;
        arrayId_Loc[i] = objlocalidade[i].id_loc;

        var loc = document.createElement("option");
        var optloc = arrayLoc[i]
        var optlocid = arrayId_Loc[i]
        loc.textContent = optloc;
        loc.value = optlocid;

        localidades.appendChild(loc);
    }

}

function limparCampos() {

    var arrayVazio = [];
    chartTemp.data.datasets[0].data = arrayVazio;
    chartUmi.data.datasets[0].data = arrayVazio;
    chartTemp.data.labels = arrayVazio;
    chartUmi.data.labels = arrayVazio;
    chartTemp.update();
    chartUmi.update();

    document.getElementById("medianaTemp").innerHTML = "";
    document.getElementById("1QTemp").innerHTML = "";
    document.getElementById("3QTemp").innerHTML = "";
    document.getElementById("mediaTemp").innerHTML = "";
    document.getElementById("medianaUmi").innerHTML = "";
    document.getElementById("1QUmi").innerHTML = "";
    document.getElementById("3QUmi").innerHTML = "";
    document.getElementById("mediaUmi").innerHTML = "";
    // contadorTempMax = 0;
    // contadorTempMin = 0;
    // contadorUmiMax = 0;
    // contadorUmiMin = 0;
}




setInterval(() => {
    if (dados == 'sem medições') {
        return;
    }
    atualizaChartComParametro(parseInt($('#refrigerador option:selected').val()));

}, 1000);
