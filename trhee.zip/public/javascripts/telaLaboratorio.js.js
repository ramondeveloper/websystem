function validacao(){
    
    
    /*if(document.cadLab.cadLabs.value=="Selecionar Laboratório"){
        alert("Selecione Laboratório");
        return false;
    }*/

    if(document.cadLab.locLab.value=="Selecionar Localidade"){
        alert("Selecionar Localidade");
        return false;
    }


}

function cancelar(){
    window.history.back();
}
