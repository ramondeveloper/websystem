$(document).ready(function () {
    //maskCep
    $("#cep_loc").mask("#####-###");


function limpa_formulário_cep() {
    // Limpa valores do formulário de cep.
    $("#end_loc").val("");
    $("#bairro_loc").val("");
    $("#cid_loc").val("");
    $("#est_loc").val("");
}

//Quando o campo cep perde o foco.
$("#cep_loc").blur(function () {

    //Nova variável "cep" somente com dígitos.
    var cep = $(this).val().replace(/\D/g, '');

    //Verifica se campo cep possui valor informado.
    if (cep != "") {

        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;

        //Valida o formato do CEP.
        if (validacep.test(cep)) {

            //Preenche os campos com "..." enquanto consulta webservice.
            $("#end_loc").val("...");
            $("#bairro_loc").val("...");
            $("#cid_loc").val("...");
            $("#est_loc").val("...");

            //Consulta o webservice viacep.com.br/
            $.getJSON("https://viacep.com.br/ws/" + cep + "/json/?callback=?", function (dados) {

                if (!("erro" in dados)) {
                    //Atualiza os campos com os valores da consulta.
                    $("#end_loc").val(dados.logradouro);
                    $("#bairro_loc").val(dados.bairro);
                    $("#cid_loc").val(dados.localidade);
                    $("#est_loc").val(dados.uf);

                } //end if.
                else {
                    //CEP pesquisado não foi encontrado.
                    limpa_formulário_cep();
                    alerta("CEP não encontrado.");
                }
            });
        } //end if.
        else {
            //cep é inválido.
            limpa_formulário_cep();
            alerta("Formato de CEP inválido.");
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
        limpa_formulário_cep();
    }
});
});
var msg;
// Validação button 
function validacao() {
    nmloc = document.getElementById("nmLoc");
    ceploc = document.getElementById("cep_loc");
    endloc = document.getElementById("end_loc");
    nloc = document.getElementById("nLoc");
    bairroloc = document.getElementById("bairro_loc");
    cidloc = document.getElementById("cid_loc");
    estLoc = document.getElementById("est_loc");
    if (nmloc.value == null || nmloc.value == "") {
        msg = "Preencha o nome da localidade que deseja registrar."
        alerta(msg);
        nmloc.focus();
    }
     else if (ceploc.value == null || ceploc.value == "") {
        msg = "Formato de CEP inválido."
        alerta(msg);
        ceploc.focus();
    }
     else if (endloc.value == null || endloc.value == "") {
        msg = "Preencha o logradouro"
        alerta(msg);
        endloc.focus();
    }
     else if (nloc.value == null || nloc.value == "") {
        msg = "Preencha o numero do endereço."
        alerta(msg);
        nloc.focus();
    }
     else if (bairroloc.value == null || bairroloc.value == "") {
        msg = "Preencha o bairro"
        alerta(msg);
        bairroloc.focus();
    }
     else if (cidloc.value == null || cidloc.value == "") {
        msg = "Preencha a cidade"
        alerta(msg);
        cidloc.focus();
    }
     else if (estLoc.value == null || estLoc.value == "") {
        msg = "Preencha o estado"
        alerta(msg);
        estLoc.focus();
    }
    else {
        cad_laboratorio();
    }
}


function cad_laboratorio() {
    $.ajax({
        method: "POST",
        url: "/cadastro/localidadeCad",
        data: $("#formLoc").serialize()
    })
        .done(function (resposta) {
            console.log(resposta);

            if (resposta == "erro") {
                msg = "Falha no cadastro, Por favor tente novamente!"
                alertaErro(msg)
            }
            else if (resposta == "Sucesso") {
                msg = "Cadastro feito com sucesso!"
                alertaSucesso(msg)
                document.getElementById("formLoc").reset();
            }
        });
}

