function populaTabela(){
    var httpLoc = new XMLHttpRequest();
    httpLoc.open("GET", "/banco/localidadeLista", false);
    httpLoc.send(null);

    var objLista = JSON.parse(httpLoc.responseText);
    console.log(objLista)

    var tabela = $('.estrutura_table').DataTable();

    for (var i = 0; i < objLista.length; i++) {
        
        tabela.row.add([
            objLista[i].id_loc,
            objLista[i].nm_Loc,
            objLista[i].endereco,
            objLista[i].numero,
            objLista[i].cep,
            objLista[i].bairro,
            objLista[i].cidade,
            objLista[i].estado,
            '<a href="#"><span class="glyphicon glyphicon-pencil"></span> Editar</a>',
            '<a data-toggle="modal" data-target="#modalMaps" onclick="initMap('+objLista[i].id_loc +')"><span id="mapsModal"></span><img src="../images/maps_icon.png" style="width: 25px; height: auto;"></a>'
        ]).draw()
                    
    }
}