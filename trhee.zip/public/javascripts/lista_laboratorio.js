function populaTabela() {

    var httpLab = new XMLHttpRequest();
    httpLab.open("GET", '/banco/laboratorioLista', false);
    httpLab.send(null);

    var objListaLab = JSON.parse(httpLab.responseText);

    var tabela = $('.estrutura_table').DataTable();

    for (var i = 0; i < objListaLab.length; i++) {

        tabela.row.add([
            objListaLab[i].id_locLab,
            objListaLab[i].desc_Lab,
            objListaLab[i].nm_Loc,
            '<a href="#"><span class="glyphicon glyphicon-pencil"></span> Editar</a>'
        ]).draw();

    }

}