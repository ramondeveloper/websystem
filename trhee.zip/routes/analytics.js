var express = require('express');
var router = express.Router();
var app = express();
const bodyParser = require("body-parser");
var summary = require('summary');
var json2xls = require('json2xls');
var fs = require('fs');

//configurando o body parser para pegar POSTS mais tarde
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());



// var dados;
var arrayUmi = [];
var arrayTemp = [];
var arrayTime = [];
var queryCond;

// VARIAVEIS APOIO UMIDADE

var mediaUmi;
var medianaUmi;
var quartil25Umi;
var quartil75Umi;

// VARIAVEIS APOIO TEMPERATURA

var mediaTemp;
var medianaTemp;
var quartil25Temp;
var quartil75Temp;

// FUNÇÃO PARA PEGAR VALORES DO BANCO E ENVIAR PARA VARIAVEL DADOS
function sqlAnalytics(query, res) {
    global.conn.request()
        .query(query)
        .then((results) => {
            // dados = results.recordset;
            verificacao(results.recordset, res)
        })// Caso der erro na procura de usuário
        .catch((err) => {
            console.log(err);
            res.json(err)
        })
}
function sqlhis(query, periodoHis, res) {
    global.conn.request()
        .query(query)
        .then((results) => {
            var coleta = results.recordset;
            if(coleta.length == 0){
                return res.send('Não existem medições neste periodo, verifique o Refrigerador selecionado!')
            }
            var xls = json2xls(coleta);
            var file = `public/${coleta[0].Refrigerador}-${periodoHis}.xlsx`;
            fs.writeFileSync(file, xls, 'binary')
            res.download(file)
            fs.stat(file, function (err, stats) {
                if (err) {
                    return console.error(err);
                }
                fs.unlink(file, function (err) {
                    if (err) {
                        return console.error(err);
                    }
                })
            })
        })// Caso der erro na procura de usuário
        .catch((err) => {
            console.log(err);
            res.json(err)
        })
}

// CRIAÇÃO DOS ARRAYS COM AS INFORMAÇÕES RETORNADAS DO BANCO
function verificacao(dados, res) {
    if (dados.length == 0) {
        res.send('sem medições');
        return;
    }
    else {
        for (var i = 0; i < dados.length; i++) {

            arrayUmi[i] = dados[i].umi;
            arrayTemp[i] = dados[i].temp;
            arrayTime[i] = dados[i].time;

        }


        // VARIAVEIS AUXILIARES PARA O USO DA API SUMMARY

        var analyticsUmi = summary(arrayUmi)
        var analyticsTemp = summary(arrayTemp)

        // Analytics UMIDADE

        mediaUmi = analyticsUmi.sum() / arrayUmi.length;
        medianaUmi = analyticsUmi.median();
        quartil25Umi = analyticsUmi.quartile(0.25);
        quartil75Umi = analyticsUmi.quartile(0.75);

        // Analytics TEMPERATURA

        mediaTemp = analyticsTemp.sum() / arrayTemp.length;
        medianaTemp = analyticsTemp.median();
        quartil25Temp = analyticsTemp.quartile(0.25);
        quartil75Temp = analyticsTemp.quartile(0.75);

        // COLOCANDO OS INFORMAÇÕES TRATADAS DENTRO DO OBJ DADOS PARA FAZER O ENVIO

        dados = {
            umi: arrayUmi,
            temp: arrayTemp,
            time: arrayTime,
            mediaUmi: mediaUmi,
            medianaUmi: medianaUmi,
            quartil25Umi: quartil25Umi,
            quartil75Umi: quartil75Umi,
            mediaTemp: mediaTemp,
            medianaTemp: medianaTemp
            ,
            quartil25Temp: quartil25Temp,
            quartil75Temp: quartil75Temp,
        };

        // ENVIO DAS INFORMAÇÕES COMO RESPOSTA

        res.send(dados);

        // LIMPA VARIAVEIS PARA PEGAR PROXIMA COLETA;

        dados = {}
        arrayUmi = [];
        arrayTemp = [];
        arrayTime = [];
    }
}

// ROTA QUE FAZ TRATATIVA DA TEMPERATURA / UMIDADE / HORA E ENVIA DENTRO DE UM OBJ COMO VETOR
// TAMBEM FAZ OS ANALYTICS E ENVIA NESTE MESMO OBJ

router.post('/coletaAnalytics/:idSen?', (req, res) => {

    // VARIAVEL QUE RECEBE O PERIODO

    var periodo = req.body.periodo;

    // QUERY BD SEM PARAMETRO

    var querybd = `SELECT temp, umi, convert(varchar(5),datahora, 114) AS time FROM Coleta where fk_arduino = ${req.params.idSen} and `

    // QUERY POR PERIODO
    console.log(periodo);
    if (periodo == 1) {
        queryCond = `datahora 
        BETWEEN cast(dateadd(HOUR, -3, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
        sqlAnalytics(querybd + queryCond, res);
    }
    else if (periodo == 6) {

        queryCond = `datahora 
        BETWEEN cast(dateadd(HOUR, -8, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
        sqlAnalytics(querybd + queryCond, res);
    }
    else if (periodo == 12) {
        queryCond = `datahora 
        BETWEEN cast(dateadd(HOUR, -14, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
        sqlAnalytics(querybd + queryCond, res);
    }
    else if (periodo == 24) {
        queryCond = `datahora 
        BETWEEN cast(dateadd(HOUR, -26, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
        sqlAnalytics(querybd + queryCond, res);
    }
    // 

})

router.get('/coletahistorico/:idSen?', (req, res) => {

    if (req.isAuthenticated()) {

        // VARIAVEL QUE RECEBE O ARDUINO E PERIODO
        var params = req.params.idSen.split(":")
        var periodoHis = params[1];
        var Arduino = params[0];

        // QUERY BD SEM PARAMETRO

        var querybd = `SELECT loc.nm_Loc as localidade, l.desc_Lab as Laboratório, A.nm_arduino as Refrigerador,temp as Temperatura, umi as Umidade, convert(varchar(5),c.datahora, 114) AS hora,convert(varchar(11), c.datahora, 103) AS data FROM Coleta 
    AS C INNER JOIN Arduino AS A ON (C.FK_arduino = A.id_Arduino) 
    INNER JOIN loc_arduino AS LOC_A ON (LOC_A.FK_arduino = A.id_Arduino)
    INNER JOIN Lab AS l ON (LOC_A.FK_lab = l.id_locLab) 
    INNER JOIN Localidade AS loc ON (loc.id_loc = l.FK_loc) where c.FK_arduino = ${Arduino} and `

        // QUERY POR PERIODO
        if (periodoHis == '1-hora') {
            queryCond = `datahora 
        BETWEEN cast(dateadd(HOUR, -3, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
        else if (periodoHis == '6-horas') {

            queryCond = `datahora 
        BETWEEN cast(dateadd(HOUR, -8, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
        else if (periodoHis == '12-horas') {
            queryCond = `datahora 
        BETWEEN cast(dateadd(HOUR, -14, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
        else if (periodoHis == '24-horas') {
            queryCond = `c.datahora 
        BETWEEN cast(dateadd(HOUR, -26, convert(smalldatetime, getdate())) as smalldatetime)
         and cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
        else if (periodoHis == '2-dias') { // 2 dias
            queryCond = `c.datahora >= cast(dateadd(DAY, -2, convert(smalldatetime, getdate())) as date)
        and c.datahora <= cast(convert(smalldatetime, getdate()) as date)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
        else if (periodoHis == '1-semana') { // uma semana
            queryCond = `c.datahora >= cast(dateadd(WEEK, -1, convert(smalldatetime, getdate())) as date)
        and c.datahora <= cast(convert(smalldatetime, getdate()) as date)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
        else if (periodoHis == '2-semanas') { // duas semanas 
            queryCond = `c.datahora >= cast(dateadd(WEEK, -2, convert(smalldatetime, getdate())) as date)
        and c.datahora <= cast(convert(smalldatetime, getdate()) as date)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
        else if (periodoHis == '1-mes') { // mes
            queryCond = `c.datahora >= cast(dateadd(MONTH, -1, convert(smalldatetime, getdate())) as date)
        and c.datahora <= cast(convert(smalldatetime, getdate()) as date)`
            sqlhis(querybd + queryCond, periodoHis, res);
        }
    }
    else {
        sessao = "Não autenticado"
        res.send(sessao);
    }
    // 

})

module.exports = router;