var express = require('express');
var router = express.Router();
var ensureLoggedIn = require('connect-ensure-login').ensureLoggedIn;
var app = express();
const bodyParser = require("body-parser");


//configurando o body parser para pegar POSTS mais tarde
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Select no banco
function execSQLQuery(sqlQry, res) {
    global.conn.request()
        .query(sqlQry)
        .then(result => res.json(result.recordset))
        .catch(err => res.json(err));
}


//                          ROTAS DE CADASTRO


// CADASTRO USUARIO

router.post('/usuariosCad', (req, res) => {
    const localidadesUsuario = parseInt(req.body.localidadesUsuario);
    const nome = req.body.nomeUsuario;
    const email = req.body.emailUsuario;
    const usuario = req.body.nicknameUsuario;
    const telefone = req.body.telefoneUsuario;
    const cpf = req.body.cpf;
    const senha = req.body.senhaUsuario;
    const nvAcesso = parseInt(req.body.nvAcesso);
    global.conn.request()
    .query(`insert into usuarios (nm_usuario, email, login, telefone, CPF, senha, FK_loc_trabalho, FK_acesso) values ('${nome}','${email}','${usuario}','${telefone}','${cpf}',PWDENCRYPT('${senha}'),'${localidadesUsuario}','${nvAcesso}');`)
    .then((results) => {
        let linhasafetadas = results.rowsAffected;
        console.log("Rota de cadastro usuario ativada, Linhas Afetadas no banco: " + linhasafetadas);
        if (linhasafetadas.length != 0) {
            res.send("Sucesso")
        }
        else if (linhasafetadas.length == 0) {
            res.send("Erro")
        }
    }) // Caso der erro na procura de usuário
    .catch((err) => {
        var erro = "" + err;
        var dpcpf = erro.indexOf(cpf);
        var dpusuario = erro.indexOf(usuario);
        var dpemail = erro.indexOf(email);
        if(dpcpf != (-1)){
            res.send("cpf-duplicado")
        }
        if(dpusuario != (-1)){
            res.send("usuario-duplicado")
        }
        if(dpemail != (-1)){
            res.send("email-duplicado")
        }
    })
})

// Update para salvar as delimitações
router.post('/configSensor', (req, res) => {
    const idSensor = parseInt(req.body.sensores);
    const temp_max = parseFloat(req.body.temp_max);
    const temp_min = parseFloat(req.body.temp_min);
    const umi_max = parseInt(req.body.umi_max);
    const umi_min = parseInt(req.body.umi_min);
    execSQLQuery(`UPDATE Arduino SET temp_max = ${temp_max} , temp_min = ${temp_min}, umi_max = ${umi_max}, umi_min = ${umi_min} WHERE id_Arduino = ${idSensor}`, res);
    res.redirect("/html/home.html");
})

// Edição Sensor
router.post('/sensorEdit', (req, res) => {

    const idSensor = parseInt(req.body.idSensor);
    const nomeSensor = req.body.nomeSensor;
    const status = req.body.statusSensor;

    try {
        sensoredit();
    }
    catch (err) {
        console.log(err);
    }
    function sensoredit() {
        if (status == 'Inativo') {
            const dataAux = "cast (DATEADD(HOUR, -3,CONVERT(smalldatetime, CURRENT_TIMESTAMP))as date)"
            execSQLQuery(`UPDATE Arduino SET nm_arduino = '${nomeSensor}', status = 0 WHERE id_Arduino = ${idSensor}; UPDATE loc_arduino SET data_desativacao = ${dataAux} WHERE FK_Arduino = ${idSensor};`, res);
        } else {
            execSQLQuery(`UPDATE Arduino SET nm_arduino = '${nomeSensor}', status = 1 WHERE id_Arduino = ${idSensor};`, res);
        }
        res.redirect("/html/home.html");
    }


})
//Localide e Lab do sensor
router.get('/loc_lab/:idSensor?', (req, res) => {
    execSQLQuery("select loc.id_loc, la.id_locLab, convert(varchar(11), locard.data_ativacao, 103) AS data_ativacao, convert(varchar(11), locard.data_desativacao, 103) AS data_desativacao from Arduino as ard inner join loc_arduino as locard on (ard.id_Arduino = locard.FK_Arduino) inner join Lab as la on (la.id_locLab = locard.FK_lab) inner join Localidade as loc on (la.FK_loc = loc.id_loc) where ard.id_Arduino = " + req.params.idSensor, res);
})


module.exports = router;