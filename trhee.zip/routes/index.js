var express = require('express');
var router = express.Router();
var passport = require('passport');


// FUNÇÃO PARA ENTENDER COMO FUNCIONA O PROCESSO DE VERIFICAÇÃO DE LOGIN
function authenticationMiddleware () {  
  return function (req, res, next) {
    if (req.isAuthenticated()) {
      return next()
    }
    res.redirect('/loginfail?fail=true')
  }
}


// ROTA INICIO APLICAÇÃO
router.get('/', function (req, res, next) {
   res.redirect('/html/home.html');
});


// ROTA EM QUE É REDIRECIONADO CASO TENHA FALHA NO LOGIN
router.get('/loginfail', function (req, res) {
  var sessao = "Não autenticado"
  if (req.query.fail)
  // FALHA NA SENHA OU USUARIO
     res.send(sessao)
  else
  // OUTROS MOTIVOS, EX: FALHA NA CONEXÃO BANCO.
    res.send(sessao)
});
// ROTA USADA NO MOMENTO EM QUE FAZEMOS LOGIN
router.post('/login',
  passport.authenticate('local', { failureRedirect: '/loginfail' }),
  function (req, res) {
    var sessao = req.session.passport.user;
    res.send(sessao);
  });

  router.get('/logout', function(req, res){
    req.logout();
    res.redirect('/');
  });


module.exports = router;
