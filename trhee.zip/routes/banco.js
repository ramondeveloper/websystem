var express = require('express');
var router = express.Router();
var ensureLoggedIn = require('connect-ensure-login').ensureLoggedIn;
var app = express();
const bodyParser = require("body-parser");

//configurando o body parser para pegar POSTS mais tarde
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Select no banco
function execSQLQuery(sqlQry, res) {
    global.conn.request()
        .query(sqlQry)
        .then(result => res.json(result.recordset))
        .catch(err => res.json(err));
}


router.get('/teste', (req, res) => {
    res.send("teste funcionou")
})

router.get('/localidade', (req, res) => {
    execSQLQuery('SELECT nm_Loc, id_loc from Localidade', res);
})
router.get('/lab/:localidade?', (req, res) => {
    execSQLQuery('SELECT id_loclab, desc_lab FROM lab where fk_loc =' + req.params.localidade, res);
})

// Rota usada pelo google maps
router.get('/locEndereco/:localidade?', (req, res) => {
    execSQLQuery('SELECT endereco, numero, bairro, estado, cidade from localidade where id_loc =' + req.params.localidade, res);
})

router.get('/arduinoNome/:labSelecionado?', (req, res) => {
    execSQLQuery('SELECT nm_arduino FROM Arduino AS C INNER JOIN loc_arduino AS Lab ON (C.id_Arduino = Lab.FK_Arduino) WHERE Lab.fk_lab = ' + req.params.labSelecionado, res);
})



// Listas
router.get('/sensorLista', (req, res) => {
    execSQLQuery('SELECT ard.id_arduino, ard.nm_arduino, loc.nm_loc, lab_ard.desc_lab, convert(varchar(11), loc_ard.data_ativacao, 103) AS data_ativacao, loc_ard.data_ativacao, loc_ard.data_desativacao, ard.status FROM arduino as ard INNER JOIN loc_arduino as loc_ard on (ard.id_arduino = loc_ard.FK_arduino) INNER JOIN Lab as lab_ard on (loc_ard.FK_lab = lab_ard.id_loclab) INNER JOIN Localidade as loc on (lab_ard.FK_loc = loc.id_loc)', res);
})

router.get('/laboratorioLista', (req, res) => {
    execSQLQuery('select id_locLab, desc_Lab, loc.nm_Loc from lab as l inner join Localidade as loc on (l.FK_loc=loc.id_loc)', res)
})
router.get('/usuarioLista', (req, res) => {
    execSQLQuery('select usu.idUsuario , usu.nm_Usuario,usu.email,usu.telefone,usu.CPF,ga.nm_grupo,loc.nm_loc from usuarios as usu inner join localidade as loc on (usu.FK_loc_trabalho = loc.id_loc) inner join gruposAcesso as ga on (usu.FK_acesso =ga.id_grupo)', res)
})

router.get('/localidadeLista', (req, res) => {
    execSQLQuery('SELECT * FROM Localidade', res);
})

// Rotas cadastro, edição, login

// Rota auxiliar cadastro de Sensores

router.get('/labSemSensor/:localidade?', (req, res) => {
    execSQLQuery("SELECT * FROM Lab AS L INNER JOIN loc_arduino AS AL ON (L.id_locLab = AL.FK_lab) WHERE L.FK_loc =" + req.params.localidade + " AND AL.FK_Arduino IS NULL", res);
})

// Configuração de Sensor
// Lista de Sensor por Lab
router.get('/sensorPorLab/:lab?', (req, res) => {
    execSQLQuery("SELECT * FROM Arduino AS ard INNER JOIN loc_arduino AS AL ON (ard.id_Arduino = AL.FK_Arduino) WHERE AL.FK_lab =" + req.params.lab, res);
})
// Sensor pelo id
router.get('/sensor/:idSensor?', (req, res) => {
    execSQLQuery("select * from Arduino where id_Arduino = " + req.params.idSensor, res);
})
// Update para salvar as delimitações
router.post('/configSensor', (req, res) => {
    const idSensor = parseInt(req.body.sensores);
    const temp_max = parseFloat(req.body.temp_max);
    const temp_min = parseFloat(req.body.temp_min);
    const umi_max = parseInt(req.body.umi_max);
    const umi_min = parseInt(req.body.umi_min);
    global.conn.request()
        .query(`UPDATE Arduino SET temp_max = ${temp_max} , temp_min = ${temp_min}, umi_max = ${umi_max}, umi_min = ${umi_min} WHERE id_Arduino = ${idSensor}`)
        .then((results) => {
            let linhasafetadas = results.rowsAffected;
            console.log("Rota de Configuração de Sensor ativada, Linhas Afetadas no banco: " + linhasafetadas);
            if (linhasafetadas.length != 0) {
                res.send("Sucesso");
            }
            else if (linhasafetadas.length == 0) {
                res.send("Erro");
            }
        })
})

// Edição Sensor
router.post('/sensorEdit', (req, res) => {

    const idSensor = parseInt(req.body.idSensor);
    const nomeSensor = req.body.nomeSensor;
    const status = req.body.statusSensor;

    try {
        sensoredit();
    }
    catch (err) {
        console.log(err);
    }
    function sensoredit() {
        if (status == 'Inativo') {
            const dataAux = "cast (DATEADD(HOUR, -3,CONVERT(smalldatetime, CURRENT_TIMESTAMP))as date)"
            execSQLQuery(`UPDATE Arduino SET nm_arduino = '${nomeSensor}', status = 0 WHERE id_Arduino = ${idSensor}; UPDATE loc_arduino SET data_desativacao = ${dataAux} WHERE FK_Arduino = ${idSensor};`, res);
        } else {
            execSQLQuery(`UPDATE Arduino SET nm_arduino = '${nomeSensor}', status = 1 WHERE id_Arduino = ${idSensor};`, res);
        }
        res.redirect("/html/home.html");
    }


})
//Localide e Lab do sensor
router.get('/loc_lab/:idSensor?', (req, res) => {
    execSQLQuery("select loc.id_loc, la.id_locLab, convert(varchar(11), locard.data_ativacao, 103) AS data_ativacao, convert(varchar(11), locard.data_desativacao, 103) AS data_desativacao from Arduino as ard inner join loc_arduino as locard on (ard.id_Arduino = locard.FK_Arduino) inner join Lab as la on (la.id_locLab = locard.FK_lab) inner join Localidade as loc on (la.FK_loc = loc.id_loc) where ard.id_Arduino = " + req.params.idSensor, res);
})

//API Email
router.get('/admLoc/:idLoc?', (req, res) => {
    execSQLQuery("SELECT email, nm_usuario from Usuarios where FK_loc_trabalho = " + req.params.idLoc + " and FK_acesso = 1", res);
})
router.get('/testeLab/:idLab?', (req, res) => {
    execSQLQuery("SELECT desc_Lab from Lab where id_locLab = " + req.params.idLab, res);
})
router.get('/testeArduino/:idArduindo?', (req, res) => {
    execSQLQuery("SELECT nm_arduino from Arduino where id_Arduino = " + req.params.idArduindo, res);
})

//                      EXEMPLOS

// router.get('/clientes/:id?', (req, res) =>{
//     let filter = '';
//     if(req.params.id) filter = ' WHERE ID=' + parseInt(req.params.id);
//     execSQLQuery('SELECT * FROM Clientes' + filter, res);
// })

// router.delete('/clientes/:id', (req, res) =>{
//     execSQLQuery('DELETE Clientes WHERE ID=' + parseInt(req.params.id), res);
// })

// router.post('/clientes', (req, res) =>{
//     const id = parseInt(req.body.id);
//     const nome = req.body.nome.substring(0,150);
//     const cpf = req.body.cpf.substring(0,11);
//     execSQLQuery(`INSERT INTO Clientes(ID, Nome, CPF) VALUES(${id},'${nome}','${cpf}')`, res);
// })

// router.patch('/clientes/:id', (req, res) =>{
//     const id = parseInt(req.params.id);
//     const nome = req.body.nome.substring(0,150);
//     const cpf = req.body.cpf.substring(0,11);
//     execSQLQuery(`UPDATE Clientes SET Nome='${nome}', CPF='${cpf}' WHERE ID=${id}`, res);
// })

module.exports = router;