var express = require('express');
var router = express.Router();
var app = express();

const TelegramBot = require('node-telegram-bot-api');

// replace the value below with the Telegram token you receive from @BotFather
const token = '732586313:AAGmY0gy5VTFKQkfDw8_4Ht77EASRv-Mvtg';

// Create a bot that uses 'polling' to fetch new updates
const bot = new TelegramBot(token, { polling: true });

// Matches "/echo [whatever]"
bot.onText(/\/echo (.+)/, (msg, match) => {
    // 'msg' is the received Message from Telegram
    // 'match' is the result of executing the regexp above on the text content
    // of the message

    const chatId = msg.chat.id;
    const resp = match[1]; // the captured "whatever"

    bot.sendMessage(chatId, resp);
});

const fs = require('fs');

// Variável global do grupo para mandar a mensagem
var grupoId;

function lerGrupo(){
    return new Promise(function (resolve, reject) {
    fs.readFile('public/grupo_telegram.txt', 'utf8', function(err, data) {  
        if (err){
            throw err;
        } 
       else{
        grupoId = data;
        resolve(true);
       }
        
    });
});
}
function salvarGrupo(grupoId){
    fs.writeFile("public/grupo_telegram.txt", grupoId, function(err) {
        if(err) {
            return console.log(err);
        }
    
        console.log("Grupo salvo!");
    });
}

bot.on('message', (msg) => {

    var str = msg.text+"";

    switch (str.toUpperCase()) {
        case 'OI BOT':
            lerGrupo();
            bot.sendMessage(grupoId, `Olá ${msg.from.first_name}, como vai?`);
            break;
        case '/CONFIGURAR_CHAT':
            salvarGrupo(msg.chat.id);
            bot.sendMessage(msg.chat.id,`Ok, ${msg.from.first_name}, irei enviar os alertas para este chat!`);
            lerGrupo();
            break;
        case '/OLAR':
            lerGrupo();
            bot.sendMessage(grupoId,'Oin :3');
            break;
        
    }

});

router.post('/alerta', (req, res) => {
    var msg = req.body.msg;
    const opts = {
        parse_mode: 'Markdown'
    };
    lerGrupo().then(()=>{
        bot.sendMessage(grupoId, msg, opts);
        res.send("Ok!");
    }) 
});

module.exports = router;