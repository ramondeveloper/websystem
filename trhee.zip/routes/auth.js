// var UsuarioService = require('../service/usuarioService');
const LocalStrategy = require('passport-local').Strategy;
var express = require('express');




module.exports = function (passport) {
    
    
    //configuraremos o passport aqui

    passport.serializeUser(function (resultado, done) {

        done(null, resultado);
    });

    passport.deserializeUser(function (resultado, done) {
        let id = resultado[0].idUsuario;
        global.conn.request().query(`select login, nm_usuario, idUsuario, FK_acesso as idAcesso, FK_loc_trabalho as idLocalidade from usuarios where idUsuario = '${id}'`)
        .then((results)=>{
            let resultado = results.recordsets[0];
            
            done(null, resultado);

        }).catch((err) =>{
            console.log(err);
        });
        
    });

    passport.use(new LocalStrategy({
        usernameField: 'username',
        passwordField: 'password'
    },
        (username, password, done) => {
            // query comparando as senhas
            global.conn.request().query(`select login, nm_usuario, idUsuario, FK_acesso as idAcesso, FK_loc_trabalho as idLocalidade from usuarios where login = '${username}' and PWDCOMPARE('${password}', senha) = 1;`)
        .then((results)=>{
            let resultado = results.recordset;
            // console.log(resultado);
            
                //Verifica se retornou usuário
               if(resultado.length == 0) {

                     return done(null, false)
                }
                                     
                // caso não entrar nos ifs anteriores retorna o usuário
                    return done(null, resultado)
                    
          
            }) // Caso der erro na procura de usuário
            .catch((err)=>{

                console.log(err);
            })
            }
    ));

    
}