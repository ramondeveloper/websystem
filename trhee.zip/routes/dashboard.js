var express = require('express');
var router = express.Router();
var ensureLoggedIn = require('connect-ensure-login').ensureLoggedIn;
var app = express();
const bodyParser = require("body-parser");


//configurando o body parser para pegar POSTS mais tarde
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Select no banco
function execSQLQuery(sqlQry, res) {
    global.conn.request()
        .query(sqlQry)
        .then(result => res.json(result.recordset))
        .catch(err => res.json(err));
}

var dados;

function sqldashboard(query, res) {
    global.conn.request()
        .query(query)
        .then((results) => {
            dados = results.recordset;
        }) // Caso der erro na procura de usuário
        .catch((err) => {
            res.json(err)
        })
}

// ROTA QUE FAZ TRATATIVA DA TEMPERATURA / UMIDADE / HORA E ENVIA DENTRO DE UM OBJ COMO VETOR

var arrayUmi = [];
var arrayTemp = [];
var arrayTime = [];
var queryCond;

router.get('/coleta/:idSen?', (req, res) => {

    // QUERY BD SEM PARAMETRO
    
    var querybd = `SELECT TOP(30) temp, umi, convert(varchar(5),datahora, 114) AS time FROM Coleta where fk_arduino = ${req.params.idSen}`
    
    // QUERY DO PERIODO

        queryCond = `order by id_coleta DESC`
        
         sqldashboard(querybd + queryCond, res);
    

    // CRIAÇÃO DOS ARRAYS COM AS INFORMAÇÕES RETORNADAS DO BANCO
    
    for (var i = 0; i < dados.length; i++) {

        arrayUmi[i] = dados[i].umi;
        arrayTemp[i] = dados[i].temp;
        arrayTime[i] = dados[i].time;

    }
    // COLOCANDO OS INFORMAÇÕES TRATADAS DENTRO DO OBJ DADOS PARA FAZER O ENVIO

    dados = {
        umi: arrayUmi.reverse(),
        temp: arrayTemp.reverse(),
        time: arrayTime.reverse(),
    };
    
    // ENVIO DAS INFORMAÇÕES COMO RESPOSTA

    res.send(dados);

    // LIMPA VARIAVEIS PARA PEGAR PROXIMA COLETA;
    
    dados = {}
    arrayUmi = [];
    arrayTemp = [];
    arrayTime = [];
})

router.get('/localidade', (req, res) => {
    execSQLQuery('SELECT nm_Loc, id_loc from Localidade', res);
})
router.get('/lab/:localidade?', (req, res) => {
    execSQLQuery('SELECT id_loclab, desc_lab FROM lab where fk_loc =' + req.params.localidade, res);
})

router.get('/arduinoNome/:labSelecionado?', (req, res) => {
    execSQLQuery('SELECT nm_arduino, id_Arduino FROM Arduino AS C INNER JOIN loc_arduino AS Lab ON (C.id_Arduino = Lab.FK_Arduino) WHERE Lab.fk_lab =' + req.params.labSelecionado, res);
})

router.get('/arduino/:idSen?', (req, res) => {
    execSQLQuery('SELECT * FROM Arduino WHERE id_Arduino =' + req.params.idSen, res);
})

router.get('/localidadePorUsuario/:idLoc?', (req, res) => {
    execSQLQuery('select nm_Loc, id_loc from Localidade where id_loc = ' + req.params.idLoc, res);
})

//                      EXEMPLOS

// router.get('/clientes/:id?', (req, res) =>{
//     let filter = '';
//     if(req.params.id) filter = ' WHERE ID=' + parseInt(req.params.id);
//     execSQLQuery('SELECT * FROM Clientes' + filter, res);
// })

// router.delete('/clientes/:id', (req, res) =>{
//     execSQLQuery('DELETE Clientes WHERE ID=' + parseInt(req.params.id), res);
// })

// router.post('/clientes', (req, res) =>{
//     const id = parseInt(req.body.id);
//     const nome = req.body.nome.substring(0,150);
//     const cpf = req.body.cpf.substring(0,11);
//     execSQLQuery(`INSERT INTO Clientes(ID, Nome, CPF) VALUES(${id},'${nome}','${cpf}')`, res);
// })

// router.patch('/clientes/:id', (req, res) =>{
//     const id = parseInt(req.params.id);
//     const nome = req.body.nome.substring(0,150);
//     const cpf = req.body.cpf.substring(0,11);
//     execSQLQuery(`UPDATE Clientes SET Nome='${nome}', CPF='${cpf}' WHERE ID=${id}`, res);
// })

module.exports = router;