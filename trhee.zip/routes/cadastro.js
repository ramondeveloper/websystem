var express = require('express');
var router = express.Router();
var ensureLoggedIn = require('connect-ensure-login').ensureLoggedIn;
var app = express();
const bodyParser = require("body-parser");


//configurando o body parser para pegar POSTS mais tarde
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//                          ROTAS DE CADASTRO


// CADASTRO USUARIO

router.post('/usuariosCad', (req, res) => {
    const localidadesUsuario = parseInt(req.body.localidadesUsuario);
    const nome = req.body.nomeUsuario;
    const email = req.body.emailUsuario;
    const usuario = req.body.nicknameUsuario;
    const telefone = req.body.telefoneUsuario;
    const cpf = req.body.cpf;
    const senha = req.body.senhaUsuario;
    const nvAcesso = parseInt(req.body.nvAcesso);
    global.conn.request()
    .query(`insert into usuarios (nm_usuario, email, login, telefone, CPF, senha, FK_loc_trabalho, FK_acesso) values ('${nome}','${email}','${usuario}','${telefone}','${cpf}',PWDENCRYPT('${senha}'),'${localidadesUsuario}','${nvAcesso}');`)
    .then((results) => {
        let linhasafetadas = results.rowsAffected;
        console.log("Rota de cadastro usuario ativada, Linhas Afetadas no banco: " + linhasafetadas);
        if (linhasafetadas.length != 0) {
            res.send("Sucesso")
        }
        else if (linhasafetadas.length == 0) {
            res.send("Erro")
        }
    }) // Caso der erro na procura de usuário
    .catch((err) => {
        var erro = "" + err;
        var dpcpf = erro.indexOf(cpf);
        var dpusuario = erro.indexOf(usuario);
        var dpemail = erro.indexOf(email);
        if(dpcpf != (-1)){
            res.send("cpf-duplicado")
        }
        if(dpusuario != (-1)){
            res.send("usuario-duplicado")
        }
        if(dpemail != (-1)){
            res.send("email-duplicado")
        }
    })
})

// CADASTRO LAB

router.post('/labCad', (req, res) => {
    const nomeLab = req.body.nmLab;
    const localidadeLab = parseInt(req.body.locLab);

    global.conn.request()
    .query("insert into Lab (desc_Lab, FK_loc) values ('" + nomeLab + "'," + localidadeLab + ");")
        .then((results) => {
            let linhasafetadas = results.rowsAffected;
            console.log("Rota de cadastro lab ativada, Linhas Afetadas no banco: " + linhasafetadas);
            if (linhasafetadas.length != 0) {
                res.send("Sucesso")
            }
            else if (linhasafetadas.length == 0) {
                res.send("Erro")
            }
        }) // Caso der erro na procura de usuário
        .catch((err) => {
            console.log(err);
        })

})

// CADASTRO DE SENSORES

router.post('/sensorCad', (req, res) => {
    const nomeSensor = req.body.nomeSensor;
    const labSensor = parseInt(req.body.labSensor);
    const dataAux = "cast (DATEADD(HOUR, -3,CONVERT(smalldatetime, CURRENT_TIMESTAMP))as date)"

    global.conn.request()
    .query("insert into Arduino (nm_arduino, arduino.status) values ('" + nomeSensor + "', 1); insert into loc_arduino (FK_lab, FK_Arduino, data_ativacao) values ("+labSensor+", (select max(id_Arduino) from Arduino),"+dataAux+");")
        .then((results) => {
            let linhasafetadas = results.rowsAffected;
            console.log("Rota de cadastro sensor ativada, Linhas Afetadas no banco: " + linhasafetadas);
            if (linhasafetadas.length != 0) {
                res.send("Sucesso")
            }
            else if (linhasafetadas.length == 0) {
                res.send("Erro")
            }
        }) // Caso der erro na procura de usuário
        .catch((err) => {
            console.log(err);
        })
})

// CADASTRO DE LOCALIDADE

router.post('/localidadeCad', (req, res) => {

    const nomeLoc = req.body.nmLoc;
    const cep = req.body.cepLoc;
    const endereco = req.body.endLoc;
    const numLoc = req.body.nLoc;
    const bairro = req.body.bairroLoc;
    const cidade = req.body.cidLoc;
    const estado = req.body.estLoc;

    global.conn.request()
    .query("insert into Localidade (cep, estado, cidade, endereco, nm_Loc, numero, bairro) values ('" + cep + "','" + estado + "','" + cidade + "','" + endereco + "','" + nomeLoc + "','" + numLoc + "','" + bairro + "');")
    .then((results) => {
        let linhasafetadas = results.rowsAffected;
        // res.redirect("/html/home.html");
        console.log("Rota de cadastro Localidade ativada, Linhas Afetadas no banco: " + linhasafetadas);
        if (linhasafetadas.length != 0) {
            res.send("Sucesso")
        }
        else if (linhasafetadas.length == 0) {
            res.send("Erro")
        }
    }) // Caso der erro na procura de usuário
    .catch((err) => {
        console.log(err);
    })
})

module.exports = router;