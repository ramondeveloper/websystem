var express = require('express');
var router = express.Router();
var app = express();
const bodyParser = require("body-parser");


//configurando o body parser para pegar POSTS mais tarde
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

router.get('/session', function (req, res) {
    var sessao;
    if(req.isAuthenticated()){
        sessao = req.session.passport.user;
        res.send(sessao);
        console.log(`Usuario ${sessao[0].nm_usuario} autenticado`)
    }
    else{
        sessao = "Não autenticado"
        res.send(sessao); 
        console.log(sessao);         
    }
    
  });



module.exports = router;
