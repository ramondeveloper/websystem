const sql = require('mssql');
const SerialPort = require('serialport');
const Readline = SerialPort.parsers.Readline;
/**
 * Get port from environment and store in Express.
 */


const config = {
    user: 'adminsystem',
    password: 'nidavellir@09',
    server: 'websystem.database.windows.net', // You can use 'localhost\\instance' to connect to named instance
    database: 'websystem',
    options: {
        encrypt: true, // Use this if you're on Windows Azure

    }
}

var dados;

// Acesso ao banco de dados SQL Server

function sqlArduino(query) {
    global.conn.request()
        .query(query)
        .then((results) => {
            dados = results.recordset;
        }) // Caso der erro na procura de usuário
        .catch((err) => {
            console.log(err)
        })
}

function registrarLeitura(temperatura, umidade, arduino) {
    return new Promise(function (resolve, reject) {

        global.conn.request()
            .query(`INSERT INTO coleta (temp, umi, datahora, FK_arduino) VALUES(${temperatura} ,${umidade},cast(dateadd(HOUR, -2, convert(smalldatetime, getdate())) as smalldatetime),${arduino});`)
            .then((results) => {
                let linhasafetadas = results.rowsAffected;
                // console.log("FOI NO ARDUINO: "+ arduino + " - temperatura: " + temperatura);
                resolve(true);
            })
            .catch((err) => {
                console.log(err);
                reject();
            })
    })
}
// conectar com o banco

sql.connect(config)
    .then(conn => {
        global.conn = conn

        console.log("conectado!");
        
        serial.SetConnection();
    }

    )
    .catch(err => console.log(err));

// Função identificar arduino

class ArduinoDataRead {

    constructor() {
        this.listData = [];
    }

    get List() {
        return this.listData;
    }

    SetConnection() {

        SerialPort.list().then(listSerialDevices => {

            let listArduinoSerial = listSerialDevices.filter(serialDevice => {
                return serialDevice.vendorId == 2341 && serialDevice.productId == 43;
            });

            if (listArduinoSerial.length != 1) {
                throw new Error("The Arduino was not connected or has many boards connceted");
            }

            console.log("Arduino found in the com %s", listArduinoSerial[0].comName);

            return listArduinoSerial[0].comName;

        }).then(arduinoCom => {

            let arduino = new SerialPort(arduinoCom, { baudRate: 9600 });

            const parser = new Readline();
            arduino.pipe(parser);

            parser.on('data', (valor) => {
                // this.listData.push(parseFloat(data.split(':')));
                this.listData.push(valor)
                var coleta = valor.split(':');
                var temp = parseFloat(coleta[0]);
                var umi = parseFloat(coleta[1]);
                const dia = "CONVERT(date, SYSDATETIME())";
                const hora = "CONVERT (time, SYSDATETIME())";
                //console.log(temp + " - " + umi);

                var sqlQuery = `select id_arduino from Arduino`;
                sqlArduino(sqlQuery);

                registrarLeitura(temp, umi, Number("1"))
                    .then((retorno) => {
                        for (var i = 1; i <= dados.length - 1; i++) {
                            if (dados[i].id_arduino%2 == 0) {
                                registrarLeitura(parseFloat((temp - Math.random() * 6)).toFixed(2), parseFloat((umi + Math.random() * 12)).toFixed(2), Number(dados[i].id_arduino))
                            }
                            if (dados[i].id_arduino%2 == 1) {
                                registrarLeitura(parseFloat((temp + Math.random() * 6)).toFixed(2), parseFloat((umi - Math.random() * 12)).toFixed(2), Number(dados[i].id_arduino))
                            }
                        }
                        return
                    });

            });

        }).catch(error => console.log(error));
    }

}
const serial = new ArduinoDataRead();


